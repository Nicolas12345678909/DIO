import os
#   importar o módulo ou biblioteca os (Integra os programas e recurso de s.o

print("#" * 60)

'''Digite www.google.com ou 8.8.8.8 como exemplo na atividade'''

ip_ou_host = input("Digite o ip po host a ser verificado: ")

#   criamos uma variável que vai receber do usuário um ip

print("-" * 60)
#   Imprimindo - 60 vezes
os.system('ping -n 6 {}.'.format(ip_ou_host))
#   Chamando system da biblioteca os - comando ping -n -num de pacotes que serão 6 {}

print("-" * 60)
#   Imprimindo - 60 vezes
